import 'babel-polyfill';
import 'whatwg-fetch';
import React from 'react';
import ReactDOM from 'react-dom';
import App from './App.jsx';

const element = <App />;

ReactDOM.render(element, document.getElementById('contents'));

