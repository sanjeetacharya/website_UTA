import React from 'react';
import Navbar from './components/Navbar.jsx';
import './App.css';
import Home from './components/pages/Home.jsx';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import Events from './components/pages/Events.jsx';
import Resources from './components/pages/Resources.jsx';
import SignUp from './components/pages/SignUp.jsx';
import Blog from './components/pages/Blog.jsx';
import About from './components/pages/About.jsx';

function App() {
  return (
    <>
      <Router>
        <Navbar />
        <Switch>
          <Route path='/' exact component={Home} />
          <Route path='/Events' component={Events} />
          <Route path='/Resources' component={Resources} />
          <Route path='/Login' component={SignUp} />
          <Route path='/Blog' component={Blog}/>
          <Route path='/SignUp' component={SignUp}/>

          <Route path='/About' component={About} />

        </Switch>
      </Router>
    </>
  );
}

export default App;
