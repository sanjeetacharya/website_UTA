import React from 'react';
import '../../App.css';

export default function Resources() {
  return <h1 className='Resources'>Resources</h1>;
}
