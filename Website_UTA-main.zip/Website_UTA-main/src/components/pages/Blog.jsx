import React from 'react';
import { Button } from '../Button.jsx';
import '../HeroSection.css';
import { useEffect } from "react";

function Blog(){
   
return (
    
    <h2>
    <div>
    <a target="_blank" href="https://www.theshorthorn.com/life_and_entertainment/technology_games/">News @ UTA</a>

        
    </div>
    </h2>
);
}
export default Blog;