"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(require("react"));

require("./Footer.css");

var _Button = require("./Button");

var _reactRouterDom = require("react-router-dom");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function Footer() {
  return /*#__PURE__*/_react.default.createElement("div", {
    className: "footer-container"
  }, /*#__PURE__*/_react.default.createElement("section", {
    className: "footer-subscription"
  }, /*#__PURE__*/_react.default.createElement("p", {
    className: "footer-subscription-heading"
  }, "Join ACM@UTA for amazing opportunites"), /*#__PURE__*/_react.default.createElement("p", {
    className: "footer-subscription-text"
  }, "You can cancel membership anytime."), /*#__PURE__*/_react.default.createElement("div", {
    className: "input-areas"
  }, /*#__PURE__*/_react.default.createElement("form", null, /*#__PURE__*/_react.default.createElement("input", {
    className: "footer-input",
    name: "email",
    type: "email",
    placeholder: "Your Email"
  }), /*#__PURE__*/_react.default.createElement(_Button.Button, {
    buttonStyle: "btn--outline"
  }, "Join")))), /*#__PURE__*/_react.default.createElement("div", {
    class: "footer-links"
  }, /*#__PURE__*/_react.default.createElement("div", {
    className: "footer-link-wrapper"
  }, /*#__PURE__*/_react.default.createElement("div", {
    class: "footer-link-items"
  }, /*#__PURE__*/_react.default.createElement("h2", null, "About Us"), /*#__PURE__*/_react.default.createElement(_reactRouterDom.Link, {
    to: "/sign-up"
  }, "UTA.edu"), /*#__PURE__*/_react.default.createElement(_reactRouterDom.Link, {
    to: "/"
  }, "Memberships"), /*#__PURE__*/_react.default.createElement(_reactRouterDom.Link, {
    to: "/"
  }, "Benefits")), /*#__PURE__*/_react.default.createElement("div", {
    class: "footer-link-items"
  }, /*#__PURE__*/_react.default.createElement("h2", null, "Contact Us"), /*#__PURE__*/_react.default.createElement(_reactRouterDom.Link, {
    to: "/"
  }, "Contact"), /*#__PURE__*/_react.default.createElement(_reactRouterDom.Link, {
    to: "/"
  }, "OIT @ UTA"), /*#__PURE__*/_react.default.createElement(_reactRouterDom.Link, {
    to: "/"
  }, "join our mailing list"))), /*#__PURE__*/_react.default.createElement("div", {
    className: "footer-link-wrapper"
  }, /*#__PURE__*/_react.default.createElement("div", {
    class: "footer-link-items"
  }, /*#__PURE__*/_react.default.createElement("h2", null, "Resources"), /*#__PURE__*/_react.default.createElement(_reactRouterDom.Link, {
    to: "/"
  }, "Upload resources"), /*#__PURE__*/_react.default.createElement(_reactRouterDom.Link, {
    to: "/"
  }, "popular resources"), /*#__PURE__*/_react.default.createElement(_reactRouterDom.Link, {
    to: "/"
  }, "Faculty recommended")), /*#__PURE__*/_react.default.createElement("div", {
    class: "footer-link-items"
  }, /*#__PURE__*/_react.default.createElement("h2", null, "Social Media"), /*#__PURE__*/_react.default.createElement(_reactRouterDom.Link, {
    to: "/"
  }, "Instagram"), /*#__PURE__*/_react.default.createElement(_reactRouterDom.Link, {
    to: "/"
  }, "Facebook"), /*#__PURE__*/_react.default.createElement(_reactRouterDom.Link, {
    to: "/"
  }, "Youtube"), /*#__PURE__*/_react.default.createElement(_reactRouterDom.Link, {
    to: "/"
  }, "Twitter")))), /*#__PURE__*/_react.default.createElement("section", {
    class: "social-media"
  }, /*#__PURE__*/_react.default.createElement("div", {
    class: "social-media-wrap"
  }, /*#__PURE__*/_react.default.createElement("div", {
    class: "footer-logo"
  }, /*#__PURE__*/_react.default.createElement(_reactRouterDom.Link, {
    to: "/",
    className: "social-logo"
  }, "ACM@UTA", /*#__PURE__*/_react.default.createElement("i", {
    class: "fab fa-fire"
  }))), /*#__PURE__*/_react.default.createElement("div", {
    class: "social-icons"
  }, /*#__PURE__*/_react.default.createElement(_reactRouterDom.Link, {
    class: "social-icon-link facebook",
    to: "/",
    target: "_blank",
    "aria-label": "Facebook"
  }, /*#__PURE__*/_react.default.createElement("i", {
    class: "fab fa-facebook-f"
  })), /*#__PURE__*/_react.default.createElement(_reactRouterDom.Link, {
    class: "social-icon-link instagram",
    to: "https://www.instagram.com/",
    target: "_blank",
    "aria-label": "Instagram"
  }, /*#__PURE__*/_react.default.createElement("i", {
    class: "fab fa-instagram"
  })), /*#__PURE__*/_react.default.createElement(_reactRouterDom.Link, {
    class: "social-icon-link youtube",
    to: "/",
    target: "_blank",
    "aria-label": "Youtube"
  }, /*#__PURE__*/_react.default.createElement("i", {
    class: "fab fa-youtube"
  })), /*#__PURE__*/_react.default.createElement(_reactRouterDom.Link, {
    class: "social-icon-link twitter",
    to: "/",
    target: "_blank",
    "aria-label": "Twitter"
  }, /*#__PURE__*/_react.default.createElement("i", {
    class: "fab fa-twitter"
  })), /*#__PURE__*/_react.default.createElement(_reactRouterDom.Link, {
    class: "social-icon-link twitter",
    to: "/",
    target: "_blank",
    "aria-label": "LinkedIn"
  }, /*#__PURE__*/_react.default.createElement("i", {
    class: "fab fa-linkedin"
  }))))));
}

var _default = Footer;
exports.default = _default;