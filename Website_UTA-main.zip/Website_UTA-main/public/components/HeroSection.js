"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(require("react"));

require("../App.css");

var _Button = require("./Button");

require("./HeroSection.css");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function HeroSection() {
  return /*#__PURE__*/_react.default.createElement("div", {
    className: "hero-container"
  }, /*#__PURE__*/_react.default.createElement("video", {
    src: "/images/UTA-light.jpg"
  }), /*#__PURE__*/_react.default.createElement("h1", null, "Welcome to ACM@UTA"), /*#__PURE__*/_react.default.createElement("p", null, "Be a part of the change"), /*#__PURE__*/_react.default.createElement("div", {
    className: "hero-btns"
  }, /*#__PURE__*/_react.default.createElement(_Button.Button, {
    className: "btns",
    buttonStyle: "btn--outline",
    buttonSize: "btn--large"
  }, "SignUp@ACM"), /*#__PURE__*/_react.default.createElement(_Button.Button, {
    className: "btns",
    buttonStyle: "btn--primary",
    buttonSize: "btn--large",
    onClick: console.log('hey')
  }, "About US ", /*#__PURE__*/_react.default.createElement("i", {
    className: "far fa-play-circle"
  }))));
}

var _default = HeroSection;
exports.default = _default;