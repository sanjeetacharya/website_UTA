"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(require("react"));

require("../../App.css");

var _Cards = _interopRequireDefault(require("../Cards"));

var _HeroSection = _interopRequireDefault(require("../HeroSection"));

var _Footer = _interopRequireDefault(require("../Footer"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function Home() {
  return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement(_HeroSection.default, null), /*#__PURE__*/_react.default.createElement(_Cards.default, null), /*#__PURE__*/_react.default.createElement(_Footer.default, null));
}

var _default = Home;
exports.default = _default;