"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Resources;

var _react = _interopRequireDefault(require("react"));

require("../../App.css");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function Resources() {
  return /*#__PURE__*/_react.default.createElement("h1", {
    className: "Resources"
  }, "Resources");
}