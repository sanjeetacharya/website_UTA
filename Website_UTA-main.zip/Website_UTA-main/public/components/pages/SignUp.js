"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = SignUp;

var _react = _interopRequireWildcard(require("react"));

var _reactRouterDom = require("react-router-dom");

require("./SignUp.css");

require("../../App.css");

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function _getRequireWildcardCache() { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function SignUp() {
  return /*#__PURE__*/_react.default.createElement("div", {
    className: "container"
  }, /*#__PURE__*/_react.default.createElement("div", {
    className: "row"
  }, /*#__PURE__*/_react.default.createElement("div", {
    className: "col-sm-3 returnHome"
  }, /*#__PURE__*/_react.default.createElement(_reactRouterDom.Link, {
    to: "/",
    className: "link"
  }, /*#__PURE__*/_react.default.createElement("i", {
    class: "fas fa-backspace"
  }), " Return Home"))), /*#__PURE__*/_react.default.createElement("div", {
    className: "row"
  }, /*#__PURE__*/_react.default.createElement("div", {
    className: "col-10 offset-1 text-center registerText"
  }, /*#__PURE__*/_react.default.createElement("h3", null, "Register to become a new user"), /*#__PURE__*/_react.default.createElement("p", null, "Already have an account? ", /*#__PURE__*/_react.default.createElement(_reactRouterDom.Link, {
    to: "/login",
    className: "link"
  }, "Log In")))), /*#__PURE__*/_react.default.createElement("div", {
    className: "row"
  }, /*#__PURE__*/_react.default.createElement("div", {
    className: "col-10 offset-1 text-center"
  }, /*#__PURE__*/_react.default.createElement("form", {
    noValidate: true,
    onSubmit: this.onSubmit
  }, /*#__PURE__*/_react.default.createElement("div", {
    className: "col-8 offset-2"
  }, /*#__PURE__*/_react.default.createElement("label", {
    htmlFor: "name"
  }, "Name:"), /*#__PURE__*/_react.default.createElement("input", {
    type: "text",
    onChange: this.onChange,
    value: this.state.name,
    id: "name",
    placeholder: "Enter your name..."
  })), /*#__PURE__*/_react.default.createElement("div", {
    className: "col-8 offset-2"
  }, /*#__PURE__*/_react.default.createElement("label", {
    htmlFor: "email"
  }, "Email:"), /*#__PURE__*/_react.default.createElement("input", {
    type: "email",
    onChange: this.onChange,
    value: this.state.email,
    id: "email",
    placeholder: "Enter your email..."
  })), /*#__PURE__*/_react.default.createElement("div", {
    className: "col-8 offset-2"
  }, /*#__PURE__*/_react.default.createElement("label", {
    htmlFor: "password"
  }, "Password:"), /*#__PURE__*/_react.default.createElement("input", {
    type: "password",
    onChange: this.onChange,
    value: this.state.password,
    id: "password",
    placeholder: "Enter a password..."
  })), /*#__PURE__*/_react.default.createElement("div", {
    className: "col-8 offset-2"
  }, /*#__PURE__*/_react.default.createElement("label", {
    htmlFor: "password2"
  }, "Confirm Password:"), /*#__PURE__*/_react.default.createElement("input", {
    type: "password",
    onChange: this.onChange,
    value: this.state.password2,
    id: "password2",
    placeholder: "Re-type your password..."
  }))))));
}