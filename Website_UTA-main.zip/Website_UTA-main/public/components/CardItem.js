"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(require("react"));

var _reactRouterDom = require("react-router-dom");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function CardItem(props) {
  return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement("li", {
    className: "cards__item"
  }, /*#__PURE__*/_react.default.createElement(_reactRouterDom.Link, {
    className: "cards__item__link",
    to: props.path
  }, /*#__PURE__*/_react.default.createElement("figure", {
    className: "cards__item__pic-wrap",
    "data-category": props.label
  }, /*#__PURE__*/_react.default.createElement("img", {
    className: "cards__item__img",
    alt: "Travel Image",
    src: props.src
  })), /*#__PURE__*/_react.default.createElement("div", {
    className: "cards__item__info"
  }, /*#__PURE__*/_react.default.createElement("h5", {
    className: "cards__item__text"
  }, props.text)))));
}

var _default = CardItem;
exports.default = _default;