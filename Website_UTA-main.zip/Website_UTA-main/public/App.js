"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(require("react"));

var _Navbar = _interopRequireDefault(require("./components/Navbar"));

require("./App.css");

var _Home = _interopRequireDefault(require("./components/pages/Home"));

var _reactRouterDom = require("react-router-dom");

var _Events = _interopRequireDefault(require("./components/pages/Events"));

var _Resources = _interopRequireDefault(require("./components/pages/Resources"));

var _SignUp = _interopRequireDefault(require("./components/pages/SignUp"));

var _Blog = _interopRequireDefault(require("./components/pages/Blog"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function App() {
  return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement(_reactRouterDom.BrowserRouter, null, /*#__PURE__*/_react.default.createElement(_Navbar.default, null), /*#__PURE__*/_react.default.createElement(_reactRouterDom.Switch, null, /*#__PURE__*/_react.default.createElement(_reactRouterDom.Route, {
    path: "/",
    exact: true,
    component: _Home.default
  }), /*#__PURE__*/_react.default.createElement(_reactRouterDom.Route, {
    path: "/Events",
    component: _Events.default
  }), /*#__PURE__*/_react.default.createElement(_reactRouterDom.Route, {
    path: "/Resources",
    component: _Resources.default
  }), /*#__PURE__*/_react.default.createElement(_reactRouterDom.Route, {
    path: "/Login",
    component: _SignUp.default
  }), /*#__PURE__*/_react.default.createElement(_reactRouterDom.Route, {
    path: "/Blog",
    component: _Blog.default
  }), /*#__PURE__*/_react.default.createElement(_reactRouterDom.Route, {
    path: "/SignUp",
    component: _SignUp.default
  }))));
}

var _default = App;
exports.default = _default;