const path = require('path');
const express = require('express');
const { connectToDb } = require('./db.js');
const { installHandler } = require('./api_handler.js');
const { connect } = require('mongodb');

const app = express();

app.use(express.static('public'));

installHandler(app);

app.get('*', (req, res) => {
    res.sendFile(path.resolve('public/index.html'));
});

(async function start() {
    await connectToDb();
    app.listen(3000, function() {
        console.log('App started on port 3000');
    });
}());