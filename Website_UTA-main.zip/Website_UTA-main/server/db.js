const { MongoClient } = require('mongodb');

let db;

async function connectToDb() {
    const url = 'mongodb://localhost/ACM';
    const client = new MongoClient(url, { useNewUrlParser: true, useUnifiedTopology: true});
    await client.connect();
    console.log('Connected to MongoDB');
    db = client.db();
}

function getDb() {
    return db;
}

module.exports = {connectToDb, getDb};