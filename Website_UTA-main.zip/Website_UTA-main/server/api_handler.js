const fs = require('fs');
const { ApolloServer } = require('apollo-server-express');

let aboutMessage = "Hello";

async function setAboutMessage(_, {message}) {
    return aboutMessage = message;
}

const resolvers = {
    Query: {
        about: () => aboutMessage,
    },
    Mutation: {
        setAboutMessage,
    },
};

const server = new ApolloServer({
    typeDefs: fs.readFileSync('./server/schema.graphql', 'utf-8'),
    resolvers,
});

function installHandler(app) {
    server.applyMiddleware({app, path: '/graphql'});
}

module.exports = { installHandler };